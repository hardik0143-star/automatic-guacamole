/* Tiny Tiffin — Parent App
   Vanilla JS, no build step required. Data comes from data/recipes.js
   and data/i18n.js (loaded before this file in index.html). */

(function () {
  "use strict";

  /* ---------------- storage: localStorage with in-memory fallback ---------------- */
  const memoryStore = {};
  const storage = {
    get(key, fallback) {
      try {
        const raw = window.localStorage.getItem(key);
        return raw !== null ? JSON.parse(raw) : fallback;
      } catch (e) {
        return key in memoryStore ? memoryStore[key] : fallback;
      }
    },
    set(key, value) {
      try {
        window.localStorage.setItem(key, JSON.stringify(value));
      } catch (e) {
        memoryStore[key] = value;
      }
    }
  };

  /* ---------------- state ---------------- */
  const RECIPES = window.TinyTiffinStore.getRecipes();
  const state = {
    lang: storage.get("tt_lang", "en"),
    tab: "find",
    favorites: new Set(storage.get("tt_favorites", [])),
    planner: storage.get("tt_planner", {}), // { "Mon-lunch": recipeId, ... }
    filters: {
      age: "all",
      time: "any",
      meal: "all",
      nutrition: null,
      allergyExclude: new Set(),
      search: ""
    }
  };

  const NUTRITION_ORDER = ["protein", "iron", "calcium", "immunity", "fiber", "energy"];
  const NUTRITION_EMOJI = { protein: "🥜", iron: "🥬", calcium: "🥛", immunity: "🍊", fiber: "🌾", energy: "⚡" };
  const AGE_GROUPS = ["1-3", "4-6", "7-9", "10-12"];
  const ALL_ALLERGENS = ["nuts", "dairy", "gluten", "soy"];
  const DAY_KEYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const MEAL_SLOTS = ["breakfast", "lunch", "snack"];

  function t(key) { return window.tinyTiffinT(state.lang, key); }
  function recipeName(r) { return r.name[state.lang] || r.name.en; }
  function recipeDesc(r) { return r.desc[state.lang] || r.desc.en; }

  /* ---------------- persistence helpers ---------------- */
  function saveFavorites() { storage.set("tt_favorites", Array.from(state.favorites)); }
  function savePlanner() { storage.set("tt_planner", state.planner); }
  function saveLang() { storage.set("tt_lang", state.lang); }

  /* ---------------- filtering ---------------- */
  function matchesFilters(r) {
    const f = state.filters;
    if (f.age !== "all" && !r.ageGroups.includes(f.age)) return false;
    if (f.time === "15" && r.cookingTimeMin > 15) return false;
    if (f.time === "25" && r.cookingTimeMin > 25) return false;
    if (f.meal !== "all" && !r.mealType.includes(f.meal)) return false;
    if (f.nutrition && !r.nutritionTags.includes(f.nutrition)) return false;
    if (f.allergyExclude.size > 0) {
      for (const a of f.allergyExclude) if (r.allergens.includes(a)) return false;
    }
    if (f.search.trim()) {
      const q = f.search.trim().toLowerCase();
      const hay = (recipeName(r) + " " + r.ingredients.join(" ")).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  }

  function filteredRecipes() { return RECIPES.filter(matchesFilters); }

  /* ---------------- toast ---------------- */
  let toastTimer = null;
  function toast(msg) {
    let el = document.getElementById("tt-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "tt-toast";
      el.className = "toast";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.display = "block";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.style.display = "none"; }, 2200);
  }

  /* ---------------- rendering ---------------- */
  const root = document.getElementById("app");

  function render() {
    root.innerHTML = `
      ${renderHeader()}
      <main class="wrap">
        ${state.tab === "find" ? renderFindTab() : ""}
        ${state.tab === "planner" ? renderPlannerTab() : ""}
        ${state.tab === "favorites" ? renderFavoritesTab() : ""}
      </main>
      <footer class="app-footer">${t("footerNote")}</footer>
    `;
    attachHeaderEvents();
    if (state.tab === "find") attachFindEvents();
    if (state.tab === "planner") attachPlannerEvents();
    if (state.tab === "favorites") attachFavoritesEvents();
  }

  function renderHeader() {
    const langOptions = window.TINY_TIFFIN_LANGUAGES.map(
      l => `<option value="${l.code}" ${l.code === state.lang ? "selected" : ""}>${l.label}</option>`
    ).join("");
    return `
      <header class="app-header">
        <div class="wrap header-row">
          <div class="brand">${brandMark()} Tiny Tiffin</div>
          <div class="header-controls">
            <select class="lang-select" id="lang-select" aria-label="Language">${langOptions}</select>
            <a class="admin-link" href="admin.html">${t("adminLink")}</a>
          </div>
        </div>
        <div class="wrap tabs">
          <button class="tab-btn ${state.tab === "find" ? "active" : ""}" data-tab="find">${t("navFind")}</button>
          <button class="tab-btn ${state.tab === "planner" ? "active" : ""}" data-tab="planner">${t("navPlanner")}</button>
          <button class="tab-btn ${state.tab === "favorites" ? "active" : ""}" data-tab="favorites">${t("navFavorites")} (${state.favorites.size})</button>
        </div>
      </header>
    `;
  }

  function brandMark() {
    return `<svg class="brand-mark" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <rect x="8" y="16" width="24" height="18" rx="4" fill="#E5A431"/>
      <rect x="8" y="10" width="24" height="8" rx="3" fill="#2B4E32"/>
      <rect x="16" y="4" width="8" height="7" rx="3" fill="#8C97A5"/>
    </svg>`;
  }

  function attachHeaderEvents() {
    document.getElementById("lang-select").addEventListener("change", (e) => {
      state.lang = e.target.value; saveLang(); render();
    });
    root.querySelectorAll(".tab-btn").forEach(btn => {
      btn.addEventListener("click", () => { state.tab = btn.dataset.tab; render(); });
    });
  }

  /* ---------- Find tab ---------- */
  function renderFindTab() {
    const results = filteredRecipes();
    return `
      <section class="hero">
        <h1 class="display">${t("heroTitle")}</h1>
        <p class="sub">${t("heroSub")}</p>
        <div class="tiffin-handle" aria-hidden="true"></div>
        <div class="tiffin-stack" role="group" aria-label="${t('heroTitle')}">
          ${NUTRITION_ORDER.map(n => `
            <button class="tiffin-tier ${state.filters.nutrition === n ? "active" : ""}" data-nutri="${n}">
              <span class="tier-emoji">${NUTRITION_EMOJI[n]}</span> ${t("nutritionGoals")[n]}
            </button>
          `).join("")}
        </div>
      </section>

      <section class="filters">
        <div class="filter-group">
          <label>${t("filterAge")}</label>
          <div class="chip-row">
            <button class="chip ${state.filters.age === "all" ? "active" : ""}" data-age="all">${t("all")}</button>
            ${AGE_GROUPS.map(a => `<button class="chip ${state.filters.age === a ? "active" : ""}" data-age="${a}">${a}</button>`).join("")}
          </div>
        </div>
        <div class="filter-group">
          <label>${t("filterTime")}</label>
          <select class="filter-select" id="time-select">
            <option value="any" ${state.filters.time === "any" ? "selected" : ""}>${t("anyTime")}</option>
            <option value="15" ${state.filters.time === "15" ? "selected" : ""}>${t("min15")}</option>
            <option value="25" ${state.filters.time === "25" ? "selected" : ""}>${t("min25")}</option>
          </select>
        </div>
        <div class="filter-group">
          <label>${t("filterMeal")}</label>
          <div class="chip-row">
            <button class="chip ${state.filters.meal === "all" ? "active" : ""}" data-meal="all">${t("all")}</button>
            ${MEAL_SLOTS.map(m => `<button class="chip ${state.filters.meal === m ? "active" : ""}" data-meal="${m}">${t(m)}</button>`).join("")}
          </div>
        </div>
        <div class="filter-group">
          <label>${t("filterAllergy")}</label>
          <div class="chip-row">
            ${ALL_ALLERGENS.map(a => `<button class="chip allergy ${state.filters.allergyExclude.has(a) ? "active" : ""}" data-allergy="${a}">${a}</button>`).join("")}
          </div>
        </div>
        <div class="filter-group">
          <label for="search-input">${t("filterSearch")}</label>
          <input type="text" class="search-input" id="search-input" placeholder="${t("searchPlaceholder")}" value="${escapeAttr(state.filters.search)}">
        </div>
        <div class="filters-foot">
          <span>${results.length} ${t("resultsCount")}</span>
          <button class="link-btn" id="clear-filters">${t("clearFilters")}</button>
        </div>
      </section>

      <section class="recipe-grid" id="recipe-grid">
        ${results.length ? results.map(r => recipeCardHTML(r)).join("") : emptyStateHTML()}
      </section>
    `;
  }

  function emptyStateHTML() {
    return `<div class="empty-state"><span class="big-emoji">🍱</span>${t("plannerEmpty") === undefined ? "" : ""}No recipes match those filters yet — try clearing one.</div>`;
  }

  function recipeCardHTML(r) {
    const isFav = state.favorites.has(r.id);
    return `
      <article class="recipe-card" data-id="${r.id}">
        <div class="card-top">
          <div class="card-emoji">${r.emoji}</div>
          <button class="fav-btn ${isFav ? "active" : ""}" data-fav="${r.id}" aria-label="${t('addFavorite')}">${isFav ? "♥" : "♡"}</button>
        </div>
        <h3>${recipeName(r)}</h3>
        <p class="desc">${recipeDesc(r)}</p>
        <div class="meta-row">
          <span class="tag time">⏱ ${r.cookingTimeMin} min</span>
          ${r.nutritionTags.slice(0, 2).map(n => `<span class="tag nutri">${NUTRITION_EMOJI[n]} ${t("nutritionGoals")[n]}</span>`).join("")}
          ${r.allergens.map(a => `<span class="tag allergen">⚠ ${a}</span>`).join("")}
        </div>
        <div class="card-actions">
          <button class="btn btn-primary btn-block" data-view="${r.id}">${t("viewRecipe")}</button>
        </div>
      </article>
    `;
  }

  function attachFindEvents() {
    root.querySelectorAll(".tiffin-tier").forEach(btn => {
      btn.addEventListener("click", () => {
        const n = btn.dataset.nutri;
        state.filters.nutrition = state.filters.nutrition === n ? null : n;
        render();
      });
    });
    root.querySelectorAll("[data-age]").forEach(btn => {
      btn.addEventListener("click", () => { state.filters.age = btn.dataset.age; render(); });
    });
    root.querySelectorAll("[data-meal]").forEach(btn => {
      btn.addEventListener("click", () => { state.filters.meal = btn.dataset.meal; render(); });
    });
    root.querySelectorAll("[data-allergy]").forEach(btn => {
      btn.addEventListener("click", () => {
        const a = btn.dataset.allergy;
        if (state.filters.allergyExclude.has(a)) state.filters.allergyExclude.delete(a);
        else state.filters.allergyExclude.add(a);
        render();
      });
    });
    const timeSelect = document.getElementById("time-select");
    if (timeSelect) timeSelect.addEventListener("change", (e) => { state.filters.time = e.target.value; render(); });
    const searchInput = document.getElementById("search-input");
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        state.filters.search = e.target.value;
        // re-render only the grid + footer count to keep focus in the input
        const grid = document.getElementById("recipe-grid");
        const results = filteredRecipes();
        grid.innerHTML = results.length ? results.map(recipeCardHTML).join("") : emptyStateHTML();
        attachCardEvents();
        const countEl = root.querySelector(".filters-foot span");
        if (countEl) countEl.textContent = `${results.length} ${t("resultsCount")}`;
      });
    }
    const clearBtn = document.getElementById("clear-filters");
    if (clearBtn) clearBtn.addEventListener("click", () => {
      state.filters = { age: "all", time: "any", meal: "all", nutrition: null, allergyExclude: new Set(), search: "" };
      render();
    });
    attachCardEvents();
  }

  function attachCardEvents() {
    root.querySelectorAll("[data-fav]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const id = btn.dataset.fav;
        if (state.favorites.has(id)) state.favorites.delete(id); else state.favorites.add(id);
        saveFavorites();
        render();
      });
    });
    root.querySelectorAll("[data-view]").forEach(btn => {
      btn.addEventListener("click", () => openRecipeModal(btn.dataset.view));
    });
  }

  /* ---------- Recipe modal ---------- */
  function openRecipeModal(id) {
    const r = RECIPES.find(x => x.id === id);
    if (!r) return;
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.id = "recipe-modal";
    backdrop.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" aria-label="${recipeName(r)}">
        <button class="modal-close" id="modal-close">✕</button>
        <div class="card-emoji" style="font-size:2.4rem">${r.emoji}</div>
        <h2>${recipeName(r)}</h2>
        <p class="desc">${recipeDesc(r)}</p>
        <div class="meta-row" style="margin-bottom:14px">
          <span class="tag time">⏱ ${r.cookingTimeMin} min</span>
          <span class="tag">${r.difficulty}</span>
          ${r.nutritionTags.map(n => `<span class="tag nutri">${NUTRITION_EMOJI[n]} ${t("nutritionGoals")[n]}</span>`).join("")}
          ${r.allergens.map(a => `<span class="tag allergen">⚠ ${a}</span>`).join("")}
        </div>
        <section>
          <h4>${t("ingredients")}</h4>
          <ul>${r.ingredients.map(i => `<li>${i}</li>`).join("")}</ul>
        </section>
        <section>
          <h4>${t("steps")}</h4>
          <ol>${r.instructions.map(s => `<li>${s}</li>`).join("")}</ol>
        </section>
        <section>
          <h4>${t("nutrition")}</h4>
          <div class="nutri-grid">
            <div class="nutri-cell"><div class="val mono">${r.nutrition.calories}</div><div class="lbl">${t("calories")}</div></div>
            <div class="nutri-cell"><div class="val mono">${r.nutrition.protein_g}g</div><div class="lbl">${t("protein")}</div></div>
            <div class="nutri-cell"><div class="val mono">${r.nutrition.iron_mg}mg</div><div class="lbl">${t("iron")}</div></div>
            <div class="nutri-cell"><div class="val mono">${r.nutrition.calcium_mg}mg</div><div class="lbl">${t("calcium")}</div></div>
          </div>
        </section>
        <div class="tip-box"><strong>💡 ${t("packingTip")}:</strong> ${r.packingTip[state.lang] || r.packingTip.en}</div>
        <div class="tip-box kid"><strong>👪 ${t("kidTip")}:</strong> ${r.kidTip[state.lang] || r.kidTip.en}</div>
        <div class="card-actions">
          <button class="btn btn-secondary" id="modal-fav" data-fav="${r.id}">${state.favorites.has(r.id) ? "♥ " + t("removeFavorite") : "♡ " + t("addFavorite")}</button>
          <button class="btn btn-primary" id="modal-plan">${t("addToPlanner")}</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) closeModal(); });
    document.getElementById("modal-close").addEventListener("click", closeModal);
    document.getElementById("modal-fav").addEventListener("click", () => {
      if (state.favorites.has(r.id)) state.favorites.delete(r.id); else state.favorites.add(r.id);
      saveFavorites();
      closeModal(); render();
      toast(state.favorites.has(r.id) ? t("removeFavorite") : t("addFavorite"));
    });
    document.getElementById("modal-plan").addEventListener("click", () => {
      closeModal();
      openPlannerPicker(r.id);
    });
  }
  function closeModal() {
    const m = document.getElementById("recipe-modal");
    if (m) m.remove();
  }

  /* ---------- Planner picker (choose day/slot for a recipe) ---------- */
  function openPlannerPicker(recipeId) {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.id = "planner-picker";
    backdrop.innerHTML = `
      <div class="modal" style="max-width:420px">
        <button class="modal-close" id="picker-close">✕</button>
        <h2>${t("addToPlanner")}</h2>
        <div class="picker-list">
          ${DAY_KEYS.map(day => MEAL_SLOTS.map(slot => `
            <div class="picker-item">
              <span>${t("days")[DAY_KEYS.indexOf(day)]} · ${t(slot)}</span>
              <button data-day="${day}" data-slot="${slot}">+</button>
            </div>
          `).join("")).join("")}
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
    document.getElementById("picker-close").addEventListener("click", () => backdrop.remove());
    backdrop.querySelectorAll("[data-day]").forEach(btn => {
      btn.addEventListener("click", () => {
        const key = `${btn.dataset.day}-${btn.dataset.slot}`;
        state.planner[key] = recipeId;
        savePlanner();
        backdrop.remove();
        toast(t("addToPlanner"));
        if (state.tab === "planner") render();
      });
    });
  }

  /* ---------- Planner tab ---------- */
  function renderPlannerTab() {
    const hasAny = Object.keys(state.planner).length > 0;
    return `
      <section style="padding-top:26px">
        <h2 class="display" style="color:var(--masala)">${t("plannerTitle")}</h2>
        <div class="planner-grid">
          ${DAY_KEYS.map((day, i) => `
            <div class="planner-day">
              <h4>${t("days")[i]}</h4>
              ${MEAL_SLOTS.map(slot => {
                const key = `${day}-${slot}`;
                const recipeId = state.planner[key];
                const r = recipeId ? RECIPES.find(x => x.id === recipeId) : null;
                if (r) {
                  return `<div class="planner-slot"><span>${r.emoji} ${recipeName(r)}</span><button data-remove="${key}">✕</button></div>`;
                }
                return `<button class="planner-add" data-add="${day}|${slot}">+ ${t(slot)}</button>`;
              }).join("")}
            </div>
          `).join("")}
        </div>
        <button class="btn btn-primary" id="grocery-btn" ${hasAny ? "" : "disabled"}>${t("groceryList")}</button>
      </section>
    `;
  }

  function attachPlannerEvents() {
    root.querySelectorAll("[data-remove]").forEach(btn => {
      btn.addEventListener("click", () => {
        delete state.planner[btn.dataset.remove];
        savePlanner();
        render();
      });
    });
    root.querySelectorAll("[data-add]").forEach(btn => {
      btn.addEventListener("click", () => openSlotPicker(...btn.dataset.add.split("|")));
    });
    const groceryBtn = document.getElementById("grocery-btn");
    if (groceryBtn) groceryBtn.addEventListener("click", openGroceryModal);
  }

  function openSlotPicker(day, slot) {
    const options = state.favorites.size > 0 ? Array.from(state.favorites) : RECIPES.map(r => r.id).slice(0, 8);
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal" style="max-width:420px">
        <button class="modal-close" id="slot-close">✕</button>
        <h2>${t("days")[DAY_KEYS.indexOf(day)]} · ${t(slot)}</h2>
        <p class="desc">${t("plannerAddFrom")}</p>
        <div class="picker-list">
          ${options.map(id => {
            const r = RECIPES.find(x => x.id === id);
            return `<div class="picker-item"><span>${r.emoji} ${recipeName(r)}</span><button data-pick="${id}">${t("addToPlanner")}</button></div>`;
          }).join("")}
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
    backdrop.querySelector("#slot-close").addEventListener("click", () => backdrop.remove());
    backdrop.querySelectorAll("[data-pick]").forEach(btn => {
      btn.addEventListener("click", () => {
        state.planner[`${day}-${slot}`] = btn.dataset.pick;
        savePlanner();
        backdrop.remove();
        render();
      });
    });
  }

  function openGroceryModal() {
    const counts = {};
    Object.values(state.planner).forEach(id => {
      const r = RECIPES.find(x => x.id === id);
      if (!r) return;
      r.ingredients.forEach(ing => { counts[ing] = (counts[ing] || 0) + 1; });
    });
    const items = Object.keys(counts).sort();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML = `
      <div class="modal">
        <button class="modal-close" id="grocery-close">✕</button>
        <h2>${t("groceryTitle")}</h2>
        ${items.length ? `<ul id="grocery-list">${items.map(i => `<li><label><input type="checkbox"> ${i}${counts[i] > 1 ? ` <span class="mono" style="color:var(--ink-soft)">×${counts[i]}</span>` : ""}</label></li>`).join("")}</ul>` : `<p class="desc">${t("groceryEmpty")}</p>`}
        <div class="card-actions">
          <button class="btn btn-secondary" id="print-list">${t("printList")}</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
    backdrop.querySelector("#grocery-close").addEventListener("click", () => backdrop.remove());
    const printBtn = backdrop.querySelector("#print-list");
    if (printBtn) printBtn.addEventListener("click", () => window.print());
  }

  /* ---------- Favorites tab ---------- */
  function renderFavoritesTab() {
    const favRecipes = RECIPES.filter(r => state.favorites.has(r.id));
    return `
      <section style="padding-top:26px">
        <h2 class="display" style="color:var(--masala)">${t("favoritesTitle")}</h2>
        <div class="recipe-grid">
          ${favRecipes.length ? favRecipes.map(recipeCardHTML).join("") : `<div class="empty-state"><span class="big-emoji">🤍</span>${t("favoritesEmpty")}</div>`}
        </div>
      </section>
    `;
  }
  function attachFavoritesEvents() { attachCardEvents(); }

  function escapeAttr(s) { return String(s).replace(/"/g, "&quot;"); }

  /* ---------------- init ---------------- */
  render();

  /* expose for potential future use / debugging */
  window.TinyTiffinApp = { state, render };
})();
