# Tiny Tiffin

Healthy tiffins. Happy kids. Stress-free mornings.

A ready-to-use web app (installable as a PWA) that helps parents pick quick,
healthy Indian vegetarian tiffin ideas for kids — filtered by age, time,
nutrition goal, and allergies — plus a weekly planner, a grocery list
generator, and an admin panel for managing the recipe database.

No build step, no npm install, no framework required. Open `index.html`
and it works.

---

## 1. Try it right now

Double-click `index.html` — it opens straight in your browser. Every
feature works locally: filtering, favorites, the weekly planner, the
grocery list, and language switching.

The one thing that needs a real web server (not `file://`) is the
offline/installable PWA behavior — see section 3.

## 2. What's inside

```
tiny-tiffin/
├── index.html        the app parents use
├── admin.html         the recipe-management screen
├── styles.css          shared design system
├── app.js               parent app logic
├── admin.js             admin panel logic
├── sw.js                 offline caching (service worker)
├── manifest.json          makes the app installable
├── icons/                  app icons
└── data/
    ├── recipes.js         the recipe database (23 recipes to start)
    ├── i18n.js              interface text in 7 languages
    └── store.js             bridges recipes.js with in-browser admin edits
```

## 3. Deploying for real (Vercel, free)

1. Create a new GitHub repo and push this whole folder to it (or drag the
   folder into a new Vercel project — Vercel supports plain static sites
   with zero configuration).
2. In Vercel: **New Project → Import** your repo → Framework preset:
   **Other** → Deploy. No build command needed.
3. That's it — you'll get a live URL, HTTPS by default, and the PWA
   (install prompt + offline support) will work correctly once served
   over HTTPS.

## 4. The admin panel

Go to `/admin.html` (there's also an "Admin" link in the app header).

- **Default password:** `tiffin2026` — open `admin.js` and change the
  `ADMIN_PASSWORD` constant near the top before sharing the link with
  anyone. This gate keeps out casual visitors; it is **not** real
  security (it's checked in the browser, so anyone can read it in page
  source). Don't use it to protect anything sensitive.
- **Add / edit / delete** recipes through a form — no code required.
- **Dashboard stats**: total recipes, average cook time, allergen count,
  age-group coverage.
- **Publishing changes**: since this is a static site with no backend,
  admin edits are saved as a *draft* in your browser (so you can keep
  working across sessions). When you're happy with the changes, click
  **Download recipes.js** and replace `data/recipes.js` in your project
  with the downloaded file, then redeploy. Your edits are now live for
  every visitor.
- **Export JSON backup** / **Import JSON** let you back up or restore
  the whole recipe set at any time.

### Going further with Firebase/Supabase

If you want admin changes to go live instantly for everyone (no
redeploy step), swap `data/store.js`'s `getRecipes`/`saveRecipes`
functions for calls to a real database:

```js
// Firebase example
import { getFirestore, collection, getDocs, setDoc, doc } from "firebase/firestore";
const db = getFirestore();

async function getRecipes() {
  const snap = await getDocs(collection(db, "recipes"));
  return snap.docs.map(d => d.data());
}
async function saveRecipe(recipe) {
  await setDoc(doc(db, "recipes", recipe.id), recipe);
}
```

Supabase works the same way with its JS client. You'd also want to move
the admin password check to real authentication (Firebase Auth /
Supabase Auth) at that point rather than the client-side gate here.

## 5. Adding a language

Open `data/i18n.js`:

1. Copy the `en` block inside `TINY_TIFFIN_STRINGS` and translate every
   value.
2. Add `{ code: "xx", label: "Your Language" }` to
   `TINY_TIFFIN_LANGUAGES`.

That's the whole process — the language picker and every screen pick it
up automatically. Seven languages ship today (English, Hindi, Marathi,
Gujarati, Tamil, Telugu, Bengali); the structure supports as many as you
want to add.

## 6. Recipe data schema

Each recipe in `data/recipes.js` follows this shape (the admin form
edits exactly these fields):

```js
{
  id: "poha",                                  // unique, no spaces
  emoji: "🍚",
  name: { en: "Vegetable Poha", hi: "..." },
  desc: { en: "...", hi: "..." },
  ageGroups: ["1-3","4-6","7-9","10-12"],
  mealType: ["breakfast","lunch","snack"],
  cookingTimeMin: 15,
  difficulty: "Easy",
  nutritionTags: ["iron","energy"],            // protein, iron, calcium, immunity, fiber, energy
  allergens: ["peanuts"],
  ingredients: ["..."],
  instructions: ["..."],
  nutrition: { calories: 220, protein_g: 5, iron_mg: 2.1, calcium_mg: 30 },
  packingTip: { en: "...", hi: "..." },
  kidTip: { en: "...", hi: "..." }
}
```

## 7. A note on data & privacy

Favorites and the weekly planner are stored only in the parent's own
browser (`localStorage`), never sent anywhere. Nothing in this app
calls out to any external server except loading the Google Fonts
stylesheet in `styles.css` — remove that `@import` if you'd rather
self-host fonts or avoid the request entirely.

## 8. Disclaimer

Recipes and nutrition figures are estimates for planning convenience,
not medical advice. Always confirm allergies and dietary needs with
your child's doctor.
