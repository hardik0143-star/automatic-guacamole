/* Tiny Tiffin — Recipe Database
   -------------------------------------------------------------
   This file is the entire "database" for the static version of
   the app. The Admin Panel edits an in-memory copy of this array
   and lets you download a replacement for this file when you're
   done — just drop it back into data/recipes.js and redeploy.

   Want live saving without redeploying? See README.md → "Going
   further with Firebase/Supabase" for the ~15 lines that swap
   this file for a real database call.
   ------------------------------------------------------------- */

window.TINY_TIFFIN_RECIPES = [
  {
    id: "poha",
    emoji: "🍚",
    name: { en: "Vegetable Poha", hi: "सब्ज़ी पोहा" },
    desc: { en: "Flattened rice tossed with peanuts, peas and a squeeze of lime.", hi: "मूंगफली, मटर और नींबू के साथ पोहा।" },
    ageGroups: ["1-3", "4-6", "7-9", "10-12"],
    mealType: ["breakfast", "snack"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["iron", "energy"],
    allergens: ["peanuts"],
    ingredients: ["1 cup flattened rice (poha)", "2 tbsp peanuts", "1/4 cup green peas", "1 small potato, diced", "1/2 tsp mustard seeds", "1 sprig curry leaves", "1/2 lime", "Salt to taste"],
    instructions: [
      "Rinse poha in a colander until soft; set aside.",
      "Heat oil, add mustard seeds, curry leaves and peanuts until fragrant.",
      "Add potato and peas, cook until tender.",
      "Fold in the poha and salt, warm through for 2 minutes.",
      "Finish with a squeeze of lime just before packing."
    ],
    nutrition: { calories: 220, protein_g: 5, iron_mg: 2.1, calcium_mg: 30 },
    packingTip: { en: "Pack lime on the side in foil so the poha doesn't turn soggy by lunchtime.", hi: "पोहा को गीला होने से बचाने के लिए नींबू अलग से पैक करें।" },
    kidTip: { en: "Cut potato extra small — it disappears into the poha and no one negotiates about it.", hi: "आलू को छोटे टुकड़ों में काटें ताकि बच्चे इसे आसानी से खा सकें।" }
  },
  {
    id: "idli",
    emoji: "⚪",
    name: { en: "Mini Idli with Chutney", hi: "मिनी इडली चटनी के साथ" },
    desc: { en: "Steamed rice cakes, soft enough for little hands to hold.", hi: "नरम चावल के केक, छोटे हाथों के लिए एकदम सही।" },
    ageGroups: ["1-3", "4-6", "7-9", "10-12"],
    mealType: ["breakfast", "lunch"],
    cookingTimeMin: 20,
    difficulty: "Medium",
    nutritionTags: ["protein", "energy"],
    allergens: [],
    ingredients: ["1 cup idli batter", "2 tbsp coconut chutney", "1/2 tsp ghee", "Pinch of gunpowder (optional)"],
    instructions: [
      "Grease a mini idli mould and pour in batter.",
      "Steam for 8–10 minutes until a toothpick comes out clean.",
      "Drizzle warm idlis with a little ghee.",
      "Pack chutney in a separate leak-proof container."
    ],
    nutrition: { calories: 180, protein_g: 4, iron_mg: 0.8, calcium_mg: 20 },
    packingTip: { en: "Keep chutney in its own tiny container — it keeps idlis from turning pink and mushy.", hi: "चटनी को अलग डिब्बे में रखें ताकि इडली गीली न हो।" },
    kidTip: { en: "Skewer a few idlis onto a toothpick for a fun 'lollipop' effect.", hi: "इडली को टूथपिक में लगाकर मज़ेदार बनाएं।" }
  },
  {
    id: "veg-paratha",
    emoji: "🫓",
    name: { en: "Stuffed Vegetable Paratha", hi: "भरवां सब्ज़ी पराठा" },
    desc: { en: "Whole wheat flatbread stuffed with grated carrot, beetroot and paneer.", hi: "गाजर, चुकंदर और पनीर से भरा पराठा।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 25,
    difficulty: "Medium",
    nutritionTags: ["iron", "calcium"],
    allergens: ["dairy", "gluten"],
    ingredients: ["1 cup whole wheat flour", "1/2 cup grated carrot", "1/4 cup grated beetroot", "1/4 cup crumbled paneer", "1 tsp cumin", "Ghee for cooking"],
    instructions: [
      "Knead dough and rest for 10 minutes.",
      "Mix grated vegetables, paneer and cumin for the filling.",
      "Roll dough, add filling, seal and roll out gently into a disc.",
      "Cook on a hot tawa with ghee until golden spots appear on both sides."
    ],
    nutrition: { calories: 260, protein_g: 7, iron_mg: 2.4, calcium_mg: 90 },
    packingTip: { en: "Wrap in foil while warm — it keeps the paratha soft for hours.", hi: "गर्म पराठे को फॉयल में लपेटें ताकि वह नरम रहे।" },
    kidTip: { en: "Cut into triangles like a pizza — same paratha, more excitement.", hi: "पराठे को त्रिकोण आकार में काटें, बच्चे इसे पसंद करेंगे।" }
  },
  {
    id: "dal-rice",
    emoji: "🍛",
    name: { en: "Soft Dal Rice Balls", hi: "दाल चावल के गोले" },
    desc: { en: "Mild yellow dal and rice, shaped into easy bite-size balls.", hi: "हल्की पीली दाल और चावल के गोले।" },
    ageGroups: ["1-3", "4-6"],
    mealType: ["lunch"],
    cookingTimeMin: 20,
    difficulty: "Easy",
    nutritionTags: ["protein", "iron"],
    allergens: [],
    ingredients: ["1/2 cup rice", "1/2 cup yellow moong dal", "1/4 tsp turmeric", "1 tsp ghee", "Pinch of asafoetida"],
    instructions: [
      "Pressure cook rice and dal together with turmeric until very soft.",
      "Mash well and mix in ghee and asafoetida.",
      "Cool slightly, then shape into small balls with wet hands.",
      "Pack once fully cooled to room temperature."
    ],
    nutrition: { calories: 200, protein_g: 6, iron_mg: 1.8, calcium_mg: 25 },
    packingTip: { en: "Line the box with a banana leaf or parchment so the balls don't stick.", hi: "गोलों को चिपकने से बचाने के लिए डिब्बे में पार्चमेंट लगाएं।" },
    kidTip: { en: "Serve with a tiny dab of ghee on top — toddlers eat these up fast.", hi: "ऊपर थोड़ा घी डालें, बच्चे इसे जल्दी खा लेंगे।" }
  },
  {
    id: "sprouts-chaat",
    emoji: "🥗",
    name: { en: "Sweet Corn & Sprouts Chaat", hi: "स्वीट कॉर्न स्प्राउट्स चाट" },
    desc: { en: "A crunchy, tangy mix of sprouted moong, corn and cucumber.", hi: "अंकुरित मूंग, मक्का और खीरे का चटपटा मिश्रण।" },
    ageGroups: ["7-9", "10-12"],
    mealType: ["snack", "lunch"],
    cookingTimeMin: 10,
    difficulty: "Easy",
    nutritionTags: ["protein", "fiber", "immunity"],
    allergens: [],
    ingredients: ["1/2 cup sprouted moong", "1/4 cup boiled sweet corn", "2 tbsp chopped cucumber", "1/2 lime", "Pinch of chaat masala"],
    instructions: [
      "Steam sprouts lightly for 3 minutes so they're easy to digest.",
      "Toss with corn and cucumber.",
      "Add lime juice and chaat masala just before packing."
    ],
    nutrition: { calories: 140, protein_g: 7, iron_mg: 1.5, calcium_mg: 35 },
    packingTip: { en: "Pack the lime and masala separately and mix at lunchtime to keep it crunchy.", hi: "कुरकुरापन बनाए रखने के लिए नींबू और मसाला अलग रखें।" },
    kidTip: { en: "A mild version (no chaat masala) works well for kids sensitive to spice.", hi: "मसाले के बिना यह बच्चों के लिए हल्का और उपयुक्त है।" }
  },
  {
    id: "veg-pulao",
    emoji: "🍚",
    name: { en: "Simple Vegetable Pulao", hi: "सादा सब्ज़ी पुलाव" },
    desc: { en: "One-pot rice with carrots, beans and green peas.", hi: "गाजर, बीन्स और मटर के साथ एक-बर्तन चावल।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 25,
    difficulty: "Easy",
    nutritionTags: ["fiber", "energy"],
    allergens: [],
    ingredients: ["1 cup basmati rice", "1/2 cup mixed vegetables", "1 bay leaf", "1 small cinnamon stick", "1 tbsp ghee"],
    instructions: [
      "Sauté whole spices in ghee until fragrant.",
      "Add vegetables and rice, stir for 2 minutes.",
      "Add water (1:1.5 ratio) and cook until fluffy.",
      "Cool slightly before packing to keep grains separate."
    ],
    nutrition: { calories: 240, protein_g: 5, iron_mg: 1.6, calcium_mg: 30 },
    packingTip: { en: "Fluff with a fork before packing so it doesn't clump in the box.", hi: "पैक करने से पहले चावल को कांटे से फुलाएं।" },
    kidTip: { en: "Cut vegetables into small matchsticks — they cook faster and kids don't pick them out.", hi: "सब्ज़ियों को छोटे टुकड़ों में काटें, बच्चे उन्हें अलग नहीं करेंगे।" }
  },
  {
    id: "paneer-roll",
    emoji: "🌯",
    name: { en: "Paneer Tikka Roll", hi: "पनीर टिक्का रोल" },
    desc: { en: "Soft roti rolled with lightly spiced paneer and bell peppers.", hi: "हल्के मसालेदार पनीर और शिमला मिर्च से भरा रोल।" },
    ageGroups: ["7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 20,
    difficulty: "Medium",
    nutritionTags: ["protein", "calcium"],
    allergens: ["dairy", "gluten"],
    ingredients: ["2 rotis", "1/2 cup paneer cubes", "1/4 cup sliced bell pepper", "1/2 tsp mild tikka masala", "1 tbsp yogurt"],
    instructions: [
      "Marinate paneer and pepper in yogurt and a pinch of tikka masala.",
      "Pan-fry until lightly charred at the edges.",
      "Warm rotis, layer with the filling and roll tightly.",
      "Wrap each roll in parchment to hold its shape."
    ],
    nutrition: { calories: 280, protein_g: 10, iron_mg: 1.4, calcium_mg: 120 },
    packingTip: { en: "Wrap tightly in parchment, twist the ends like a candy wrapper — no unrolling in the bag.", hi: "रोल को पार्चमेंट में कसकर लपेटें।" },
    kidTip: { en: "Go easy on the masala for younger kids — the char already adds plenty of flavour.", hi: "छोटे बच्चों के लिए मसाला कम रखें।" }
  },
  {
    id: "moong-cheela",
    emoji: "🥞",
    name: { en: "Moong Dal Cheela", hi: "मूंग दाल चीला" },
    desc: { en: "Savoury lentil pancakes, soft in the middle and lightly crisp outside.", hi: "नरम और हल्के कुरकुरे मूंग दाल के चीले।" },
    ageGroups: ["1-3", "4-6", "7-9"],
    mealType: ["breakfast", "snack"],
    cookingTimeMin: 20,
    difficulty: "Easy",
    nutritionTags: ["protein", "iron"],
    allergens: [],
    ingredients: ["1 cup split moong dal, soaked", "1/2 inch ginger", "1 green chilli (optional)", "Pinch of turmeric", "Ghee for cooking"],
    instructions: [
      "Blend soaked dal with ginger and a little water into a smooth batter.",
      "Pour a ladleful onto a hot greased tawa and spread thin.",
      "Cook both sides until light golden.",
      "Cool completely before stacking in the tiffin."
    ],
    nutrition: { calories: 190, protein_g: 9, iron_mg: 2.0, calcium_mg: 40 },
    packingTip: { en: "Layer parchment between each cheela so they don't stick together.", hi: "चीलों के बीच पार्चमेंट रखें ताकि वे चिपकें नहीं।" },
    kidTip: { en: "Skip the chilli and add a pinch of grated carrot for natural sweetness.", hi: "मिर्च छोड़ें और थोड़ी कद्दूकस की हुई गाजर डालें।" }
  },
  {
    id: "upma",
    emoji: "🥣",
    name: { en: "Vegetable Semolina Upma", hi: "सब्ज़ी सूजी उपमा" },
    desc: { en: "Roasted semolina simmered with carrots, peas and curry leaves.", hi: "गाजर, मटर और करी पत्ते के साथ भुनी सूजी।" },
    ageGroups: ["1-3", "4-6", "7-9", "10-12"],
    mealType: ["breakfast"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["energy", "fiber"],
    allergens: [],
    ingredients: ["1 cup semolina (rava)", "1/4 cup mixed vegetables", "1 tsp mustard seeds", "1 sprig curry leaves", "2 cups water"],
    instructions: [
      "Dry roast semolina until fragrant; set aside.",
      "Temper mustard seeds and curry leaves in oil, add vegetables and cook briefly.",
      "Add water and bring to a boil, then stir in semolina.",
      "Cook on low heat, stirring, until it thickens and pulls from the sides."
    ],
    nutrition: { calories: 210, protein_g: 5, iron_mg: 1.2, calcium_mg: 22 },
    packingTip: { en: "Pack slightly moist — upma stiffens as it cools, so a splash extra water helps.", hi: "उपमा को थोड़ा नम रखें ताकि वह ठंडा होने पर सख्त न हो।" },
    kidTip: { en: "A drizzle of coconut milk on top makes it noticeably creamier for picky eaters.", hi: "ऊपर थोड़ा नारियल दूध डालने से यह मलाईदार बनता है।" }
  },
  {
    id: "dhokla",
    emoji: "🟨",
    name: { en: "Steamed Besan Dhokla", hi: "स्टीम्ड बेसन ढोकला" },
    desc: { en: "Light, spongy steamed gram-flour squares with a mustard tempering.", hi: "हल्के, स्पंजी बेसन के टुकड़े राई के तड़के के साथ।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["snack", "lunch"],
    cookingTimeMin: 30,
    difficulty: "Medium",
    nutritionTags: ["protein", "fiber"],
    allergens: [],
    ingredients: ["1 cup gram flour (besan)", "1/2 tsp fruit salt (ENO)", "1 tsp mustard seeds", "1 sprig curry leaves", "1 tsp sugar"],
    instructions: [
      "Whisk besan with water, salt and sugar into a smooth batter.",
      "Add fruit salt just before steaming; pour into a greased tray.",
      "Steam for 15–18 minutes until a toothpick comes out clean.",
      "Temper mustard seeds and curry leaves in hot oil and pour over the top.",
      "Cool and cut into squares."
    ],
    nutrition: { calories: 170, protein_g: 6, iron_mg: 1.1, calcium_mg: 18 },
    packingTip: { en: "Pack the tempering oil lightly drizzled, not pooled, to avoid a soggy box.", hi: "तड़के का तेल हल्का डालें ताकि डिब्बा गीला न हो।" },
    kidTip: { en: "Cut into fun shapes with a small cookie cutter for younger kids.", hi: "छोटे बच्चों के लिए कुकी कटर से मज़ेदार आकार बनाएं।" }
  },
  {
    id: "veg-sandwich",
    emoji: "🥪",
    name: { en: "Mixed Vegetable Sandwich", hi: "मिक्स वेजिटेबल सैंडविच" },
    desc: { en: "Whole wheat bread layered with cucumber, tomato, and a mild green chutney.", hi: "खीरे, टमाटर और हरी चटनी के साथ ब्रेड सैंडविच।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["lunch", "snack"],
    cookingTimeMin: 10,
    difficulty: "Easy",
    nutritionTags: ["fiber"],
    allergens: ["gluten"],
    ingredients: ["2 slices whole wheat bread", "2 tbsp mint-coriander chutney", "Cucumber and tomato slices", "1 tsp butter"],
    instructions: [
      "Spread butter and chutney on the bread slices.",
      "Layer cucumber and tomato evenly.",
      "Press together and trim edges if preferred.",
      "Cut into triangles or fingers."
    ],
    nutrition: { calories: 200, protein_g: 5, iron_mg: 1.0, calcium_mg: 40 },
    packingTip: { en: "Keep tomato slices thin and pat dry — it's the main cause of a soggy sandwich.", hi: "टमाटर को पतला काटें और सुखाकर रखें ताकि सैंडविच गीला न हो।" },
    kidTip: { en: "Use a cookie cutter for a star or heart shaped sandwich — same recipe, more delight.", hi: "कुकी कटर से तारे या दिल के आकार का सैंडविच बनाएं।" }
  },
  {
    id: "oats-pancake",
    emoji: "🥞",
    name: { en: "Banana Oats Pancake", hi: "केला ओट्स पैनकेक" },
    desc: { en: "Naturally sweet pancakes made with mashed banana and rolled oats.", hi: "केले और ओट्स से बने मीठे पैनकेक।" },
    ageGroups: ["1-3", "4-6", "7-9"],
    mealType: ["breakfast", "snack"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["fiber", "energy"],
    allergens: [],
    ingredients: ["1 ripe banana", "1/2 cup rolled oats", "2 tbsp milk", "Pinch of cinnamon", "Ghee for cooking"],
    instructions: [
      "Blend oats into a coarse flour.",
      "Mash banana and mix with oats flour, milk and cinnamon into a batter.",
      "Cook small pancakes on a greased tawa until golden on both sides.",
      "Cool before packing."
    ],
    nutrition: { calories: 180, protein_g: 4, iron_mg: 1.3, calcium_mg: 45 },
    packingTip: { en: "Pack a few extra — these disappear faster than expected at snack time.", hi: "थोड़े अतिरिक्त पैनकेक पैक करें, ये जल्दी खत्म हो जाते हैं।" },
    kidTip: { en: "No added sugar needed — ripe banana makes these plenty sweet.", hi: "पका केला ही काफी मीठा होता है, चीनी की ज़रूरत नहीं।" }
  },
  {
    id: "rajma-rice",
    emoji: "🍚",
    name: { en: "Mild Rajma Rice", hi: "हल्का राजमा चावल" },
    desc: { en: "Kidney beans in a gentle tomato gravy, served over soft rice.", hi: "टमाटर की हल्की ग्रेवी में राजमा, नरम चावल के साथ।" },
    ageGroups: ["7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 30,
    difficulty: "Medium",
    nutritionTags: ["protein", "iron", "fiber"],
    allergens: [],
    ingredients: ["1/2 cup boiled rajma", "1/4 cup tomato puree", "1 cup cooked rice", "1/4 tsp cumin powder", "1 tsp ghee"],
    instructions: [
      "Sauté tomato puree with cumin in ghee until it thickens.",
      "Add boiled rajma and simmer for 10 minutes, mashing a few beans for body.",
      "Pack rice and rajma in separate compartments to keep textures distinct."
    ],
    nutrition: { calories: 260, protein_g: 9, iron_mg: 2.6, calcium_mg: 50 },
    packingTip: { en: "Use a compartment box — rajma gravy against rice all lunch period turns mushy.", hi: "राजमा और चावल को अलग-अलग खानों में रखें।" },
    kidTip: { en: "Mash a portion of the beans smooth — easier for younger kids to manage.", hi: "छोटे बच्चों के लिए राजमा को मैश करके दें।" }
  },
  {
    id: "chickpea-salad",
    emoji: "🥗",
    name: { en: "Chickpea & Cucumber Salad", hi: "चना खीरा सलाद" },
    desc: { en: "Protein-rich chickpeas tossed with cucumber, lemon and mint.", hi: "प्रोटीन से भरपूर चना, खीरा, नींबू और पुदीना।" },
    ageGroups: ["7-9", "10-12"],
    mealType: ["lunch", "snack"],
    cookingTimeMin: 10,
    difficulty: "Easy",
    nutritionTags: ["protein", "fiber"],
    allergens: [],
    ingredients: ["1 cup boiled chickpeas", "1/4 cup chopped cucumber", "1 tbsp chopped mint", "1/2 lime", "Pinch of black salt"],
    instructions: [
      "Toss chickpeas with cucumber and mint.",
      "Add lime juice and black salt just before packing.",
      "Chill briefly if time allows for a fresher bite."
    ],
    nutrition: { calories: 190, protein_g: 8, iron_mg: 2.2, calcium_mg: 45 },
    packingTip: { en: "Pack lime separately so the salad stays crisp rather than watery.", hi: "सलाद को कुरकुरा रखने के लिए नींबू अलग रखें।" },
    kidTip: { en: "A spoon of grated cheese on top wins over reluctant salad eaters.", hi: "ऊपर थोड़ा कद्दूकस पनीर डालने से बच्चे इसे पसंद करेंगे।" }
  },
  {
    id: "veg-khichdi",
    emoji: "🍲",
    name: { en: "Vegetable Khichdi", hi: "सब्ज़ी खिचड़ी" },
    desc: { en: "One-pot comfort food of rice, moong dal and soft vegetables.", hi: "चावल, मूंग दाल और नरम सब्ज़ियों की आरामदायक खिचड़ी।" },
    ageGroups: ["1-3", "4-6", "7-9"],
    mealType: ["lunch"],
    cookingTimeMin: 20,
    difficulty: "Easy",
    nutritionTags: ["protein", "iron", "immunity"],
    allergens: [],
    ingredients: ["1/2 cup rice", "1/4 cup split moong dal", "1/4 cup mixed vegetables", "Pinch of turmeric", "1 tsp ghee"],
    instructions: [
      "Wash rice and dal together, add turmeric and vegetables.",
      "Pressure cook with 3 cups water until soft and porridge-like.",
      "Finish with a spoon of ghee before packing."
    ],
    nutrition: { calories: 210, protein_g: 7, iron_mg: 1.9, calcium_mg: 28 },
    packingTip: { en: "Khichdi thickens as it cools — pack a small extra spoon of warm water on the side.", hi: "खिचड़ी ठंडी होने पर गाढ़ी हो जाती है, थोड़ा पानी साथ रखें।" },
    kidTip: { en: "This is often the easiest recipe on the whole list for a child who's unwell or fussy.", hi: "यह बीमार या नखरे करने वाले बच्चों के लिए सबसे आसान व्यंजन है।" }
  },
  {
    id: "stuffed-paratha-paneer",
    emoji: "🫓",
    name: { en: "Paneer Stuffed Paratha", hi: "पनीर पराठा" },
    desc: { en: "A protein-forward paratha stuffed with mildly spiced crumbled paneer.", hi: "हल्के मसालेदार पनीर से भरा पराठा।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 25,
    difficulty: "Medium",
    nutritionTags: ["protein", "calcium"],
    allergens: ["dairy", "gluten"],
    ingredients: ["1 cup whole wheat flour", "1/2 cup crumbled paneer", "1/4 tsp garam masala", "1 tbsp chopped coriander", "Ghee for cooking"],
    instructions: [
      "Mix paneer with garam masala and coriander for the filling.",
      "Stuff into rolled dough discs, seal and roll out gently.",
      "Cook on a hot tawa with ghee until golden on both sides."
    ],
    nutrition: { calories: 270, protein_g: 9, iron_mg: 1.6, calcium_mg: 110 },
    packingTip: { en: "Wrap warm in foil — it keeps the paneer filling from drying out.", hi: "गर्म पराठे को फॉयल में लपेटें।" },
    kidTip: { en: "Serve with a small side of ketchup — a well-known peace treaty with picky eaters.", hi: "थोड़ी केचप के साथ परोसें, बच्चे खुश होंगे।" }
  },
  {
    id: "ragi-porridge",
    emoji: "🥣",
    name: { en: "Ragi (Finger Millet) Porridge", hi: "रागी दलिया" },
    desc: { en: "A calcium-rich, naturally sweet porridge made from finger millet.", hi: "रागी से बना कैल्शियम से भरपूर दलिया।" },
    ageGroups: ["1-3", "4-6"],
    mealType: ["breakfast"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["calcium", "iron"],
    allergens: [],
    ingredients: ["3 tbsp ragi flour", "1 cup milk or water", "1 tsp jaggery", "Pinch of cardamom"],
    instructions: [
      "Mix ragi flour with a little water to form a smooth, lump-free paste.",
      "Bring milk to a gentle boil, then whisk in the paste.",
      "Simmer for 5–6 minutes, stirring often, until thickened.",
      "Sweeten with jaggery and a pinch of cardamom."
    ],
    nutrition: { calories: 150, protein_g: 4, iron_mg: 2.5, calcium_mg: 160 },
    packingTip: { en: "Use a wide-mouth thermal flask — it keeps porridge warm and easy to spoon out.", hi: "गर्म रखने के लिए वाइड-माउथ थर्मस का उपयोग करें।" },
    kidTip: { en: "One of the few naturally calcium-rich options here — great for growth years.", hi: "यह कैल्शियम से भरपूर है, बढ़ते बच्चों के लिए बेहतरीन।" }
  },
  {
    id: "vermicelli-upma",
    emoji: "🍜",
    name: { en: "Vegetable Vermicelli Upma", hi: "सब्ज़ी सेवई उपमा" },
    desc: { en: "Roasted vermicelli tossed with carrots, beans and a light tempering.", hi: "गाजर, बीन्स के साथ भुनी सेवई।" },
    ageGroups: ["1-3", "4-6", "7-9", "10-12"],
    mealType: ["breakfast", "snack"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["fiber", "energy"],
    allergens: ["gluten"],
    ingredients: ["1 cup vermicelli", "1/4 cup mixed vegetables", "1 tsp mustard seeds", "1 sprig curry leaves", "1.5 cups water"],
    instructions: [
      "Dry roast vermicelli until light golden; set aside.",
      "Temper mustard seeds and curry leaves, add vegetables and cook briefly.",
      "Add water, bring to a boil, then stir in the roasted vermicelli.",
      "Cook covered on low heat until water is absorbed."
    ],
    nutrition: { calories: 200, protein_g: 4, iron_mg: 1.0, calcium_mg: 20 },
    packingTip: { en: "Let it cool fully before closing the lid to stop condensation making it sticky.", hi: "डिब्बा बंद करने से पहले इसे पूरी तरह ठंडा होने दें।" },
    kidTip: { en: "Thinner vermicelli strands feel less 'noodle-like' for kids who are picky about texture.", hi: "पतली सेवई बनावट में हल्की लगती है।" }
  },
  {
    id: "spinach-paratha",
    emoji: "🫓",
    name: { en: "Spinach (Palak) Paratha", hi: "पालक पराठा" },
    desc: { en: "Vibrant green flatbread with pureed spinach folded into the dough.", hi: "पालक की प्यूरी से बना हरा पराठा।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 20,
    difficulty: "Easy",
    nutritionTags: ["iron", "immunity"],
    allergens: ["gluten"],
    ingredients: ["1 cup whole wheat flour", "1/2 cup blanched spinach puree", "Pinch of ajwain", "Ghee for cooking"],
    instructions: [
      "Knead flour with spinach puree and ajwain into a soft dough.",
      "Roll into discs and cook on a hot tawa with ghee until golden."
    ],
    nutrition: { calories: 230, protein_g: 6, iron_mg: 3.0, calcium_mg: 60 },
    packingTip: { en: "Pack with a small side of yogurt or pickle for kids who want a dip.", hi: "साथ में थोड़ा दही या अचार पैक करें।" },
    kidTip: { en: "The green color is easiest to introduce alongside a familiar side like curd.", hi: "हरे रंग को दही के साथ परोसना आसान होता है।" }
  },
  {
    id: "fruit-nut-mix",
    emoji: "🍎",
    name: { en: "Fruit & Nut Snack Box", hi: "फल और मेवा स्नैक बॉक्स" },
    desc: { en: "A no-cook mix of seasonal fruit, almonds and raisins.", hi: "मौसमी फल, बादाम और किशमिश का मिश्रण।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["snack"],
    cookingTimeMin: 5,
    difficulty: "Easy",
    nutritionTags: ["immunity", "energy"],
    allergens: ["nuts"],
    ingredients: ["1/2 cup chopped seasonal fruit", "5 almonds", "1 tbsp raisins"],
    instructions: [
      "Chop fruit into bite-size pieces just before packing to avoid browning.",
      "Add almonds and raisins in a separate small compartment."
    ],
    nutrition: { calories: 130, protein_g: 3, iron_mg: 0.9, calcium_mg: 25 },
    packingTip: { en: "A few drops of lime on apple or banana slices keep them from browning by lunch.", hi: "सेब या केले पर नींबू की बूंदें डालने से वे काले नहीं पड़ेंगे।" },
    kidTip: { en: "Great zero-cook option for rushed mornings — assemble in under 5 minutes.", hi: "जल्दी वाली सुबह के लिए बेहतरीन, 5 मिनट में तैयार।" }
  },
  {
    id: "veg-frankie",
    emoji: "🌯",
    name: { en: "Vegetable Frankie", hi: "वेजिटेबल फ्रैंकी" },
    desc: { en: "A soft roti rolled with spiced potato-pea filling.", hi: "मसालेदार आलू-मटर भरावन के साथ रोल।" },
    ageGroups: ["7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 20,
    difficulty: "Medium",
    nutritionTags: ["fiber", "energy"],
    allergens: ["gluten"],
    ingredients: ["2 rotis", "1 boiled potato, mashed", "2 tbsp green peas", "1/4 tsp mild chaat masala", "1 tsp oil"],
    instructions: [
      "Sauté potato and peas with a pinch of chaat masala.",
      "Warm the roti, spread the filling and roll tightly.",
      "Wrap in parchment to hold its shape."
    ],
    nutrition: { calories: 250, protein_g: 5, iron_mg: 1.3, calcium_mg: 30 },
    packingTip: { en: "Toast the roti lightly before rolling — it holds up better against the filling's moisture.", hi: "रोटी को हल्का सेकें ताकि वह भरावन की नमी सह सके।" },
    kidTip: { en: "Cut in half so it's easier for smaller hands to hold and finish.", hi: "छोटे हाथों के लिए इसे आधा काट दें।" }
  },
  {
    id: "sooji-halwa",
    emoji: "🍮",
    name: { en: "Sooji Halwa (Occasional Treat)", hi: "सूजी हलवा (कभी-कभी)" },
    desc: { en: "A warm, ghee-roasted semolina sweet — best kept for special mornings.", hi: "घी में भुनी सूजी से बनी मिठाई, खास दिनों के लिए।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["breakfast", "snack"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["energy"],
    allergens: [],
    ingredients: ["1/2 cup semolina (sooji)", "2 tbsp ghee", "1/4 cup jaggery or sugar", "1 cup water", "A few cashews"],
    instructions: [
      "Roast semolina in ghee until golden and fragrant.",
      "Add hot water carefully and stir to avoid lumps.",
      "Stir in jaggery and cook until it thickens and pulls from the sides.",
      "Garnish with a few roasted cashews."
    ],
    nutrition: { calories: 260, protein_g: 3, iron_mg: 0.8, calcium_mg: 15 },
    packingTip: { en: "Keep this an occasional pack rather than a daily one, given the added sugar.", hi: "अधिक चीनी के कारण इसे कभी-कभी ही पैक करें।" },
    kidTip: { en: "A nice reward-day recipe, e.g. after an exam or a first day back at school.", hi: "यह किसी खास दिन जैसे परीक्षा के बाद देने के लिए अच्छा है।" }
  },
  {
    id: "coconut-rice",
    emoji: "🥥",
    name: { en: "South Indian Coconut Rice", hi: "नारियल चावल" },
    desc: { en: "Fragrant rice tossed with fresh coconut, curry leaves and a light tempering.", hi: "ताज़े नारियल और करी पत्ते के साथ चावल।" },
    ageGroups: ["4-6", "7-9", "10-12"],
    mealType: ["lunch"],
    cookingTimeMin: 15,
    difficulty: "Easy",
    nutritionTags: ["energy", "immunity"],
    allergens: [],
    ingredients: ["1 cup cooked rice", "1/4 cup grated fresh coconut", "1 tsp mustard seeds", "1 sprig curry leaves", "1 dried red chilli (optional)"],
    instructions: [
      "Temper mustard seeds, curry leaves and chilli in oil.",
      "Add grated coconut and sauté briefly.",
      "Fold in cooked rice and mix well until evenly coated."
    ],
    nutrition: { calories: 230, protein_g: 4, iron_mg: 1.1, calcium_mg: 20 },
    packingTip: { en: "Best packed the same morning — fresh coconut doesn't keep well overnight.", hi: "ताज़ा नारियल रात भर नहीं टिकता, इसे सुबह ही बनाएं।" },
    kidTip: { en: "Leave the chilli out entirely — the coconut and curry leaves already carry the flavour.", hi: "मिर्च छोड़ दें, नारियल और करी पत्ता ही स्वाद के लिए काफी हैं।" }
  }
];
