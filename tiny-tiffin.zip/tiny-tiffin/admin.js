/* Tiny Tiffin — Admin Panel
   This is a client-side admin for a static, no-backend build:
   it edits a draft copy of the recipe list in this browser and
   lets you download a finished data/recipes.js to publish.

   IMPORTANT: the password gate below is a convenience to keep
   casual visitors out of the editing screen — it is NOT secure
   (anyone can read it in the page source). Don't use it to
   protect anything sensitive. See README.md for how to add real
   authentication once you connect a backend. */

(function () {
  "use strict";

  const ADMIN_PASSWORD = "tiffin2026"; // change this, then tell your team the new one

  const NUTRITION_ORDER = ["protein", "iron", "calcium", "immunity", "fiber", "energy"];
  const AGE_GROUPS = ["1-3", "4-6", "7-9", "10-12"];
  const MEAL_SLOTS = ["breakfast", "lunch", "snack"];
  const ALLERGENS = ["nuts", "dairy", "gluten", "soy"];

  let recipes = window.TinyTiffinStore.getRecipes().map((r) => JSON.parse(JSON.stringify(r))); // deep copy for safe editing
  let authed = sessionStorage_get("tt_admin_authed", false);
  let editingId = null; // null = not editing / creating new

  function sessionStorage_get(key, fallback) {
    try {
      const v = window.sessionStorage.getItem(key);
      return v !== null ? JSON.parse(v) : fallback;
    } catch (e) { return fallback; }
  }
  function sessionStorage_set(key, value) {
    try { window.sessionStorage.setItem(key, JSON.stringify(value)); } catch (e) {}
  }

  const root = document.getElementById("admin-app");

  function render() {
    root.innerHTML = authed ? renderDashboard() : renderLogin();
    attachEvents();
  }

  /* ---------------- login gate ---------------- */
  function renderLogin() {
    return `
      <div class="admin-login">
        <div class="admin-login-card">
          <div class="brand">${brandMark()} Tiny Tiffin Admin</div>
          <p class="desc">Enter the admin password to manage recipes.</p>
          <input type="password" id="pw-input" placeholder="Admin password" class="search-input" autofocus>
          <button class="btn btn-primary btn-block" id="pw-submit" style="margin-top:12px">Sign in</button>
          <p class="hint">Default password is set in admin.js — change <code>ADMIN_PASSWORD</code> before sharing this link. This gate keeps out casual visitors; it is not secure against a determined one.</p>
          <a class="link-btn" href="index.html">← Back to the app</a>
        </div>
      </div>
    `;
  }

  function brandMark() {
    return `<svg width="30" height="30" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <rect x="8" y="16" width="24" height="18" rx="4" fill="#E5A431"/>
      <rect x="8" y="10" width="24" height="8" rx="3" fill="#2B4E32"/>
      <rect x="16" y="4" width="8" height="7" rx="3" fill="#8C97A5"/>
    </svg>`;
  }

  /* ---------------- dashboard ---------------- */
  function renderDashboard() {
    const stats = computeStats();
    return `
      <header class="admin-header">
        <div class="brand">${brandMark()} Tiny Tiffin Admin</div>
        <div class="header-controls">
          <a class="admin-link" href="index.html">View app</a>
          <button class="admin-link" id="logout-btn">Sign out</button>
        </div>
      </header>
      <main class="wrap admin-main">
        ${window.TinyTiffinStore.hasDraft() ? `<div class="draft-banner">You're viewing unsaved draft changes stored in this browser. Download the updated file below when you're ready to publish them for everyone.</div>` : ""}

        <section class="stat-grid">
          <div class="stat-card"><div class="stat-num mono">${stats.total}</div><div class="stat-lbl">Total recipes</div></div>
          <div class="stat-card"><div class="stat-num mono">${stats.avgTime}</div><div class="stat-lbl">Avg. cook time (min)</div></div>
          <div class="stat-card"><div class="stat-num mono">${stats.withAllergens}</div><div class="stat-lbl">Contain an allergen</div></div>
          <div class="stat-card"><div class="stat-num mono">${stats.byAge["1-3"]}</div><div class="stat-lbl">Suitable for ages 1–3</div></div>
        </section>

        <section class="admin-toolbar">
          <button class="btn btn-primary" id="add-recipe-btn">+ Add recipe</button>
          <div class="toolbar-right">
            <button class="btn btn-secondary" id="export-btn">Download recipes.js</button>
            <button class="btn btn-secondary" id="export-json-btn">Export JSON backup</button>
            <label class="btn btn-secondary" style="margin:0">Import JSON<input type="file" id="import-input" accept="application/json" style="display:none"></label>
            ${window.TinyTiffinStore.hasDraft() ? `<button class="btn btn-secondary" id="discard-draft-btn">Discard draft</button>` : ""}
          </div>
        </section>

        <section class="admin-table-wrap">
          <table class="admin-table">
            <thead><tr><th>Recipe</th><th>Ages</th><th>Time</th><th>Nutrition</th><th>Allergens</th><th></th></tr></thead>
            <tbody>
              ${recipes.map((r) => `
                <tr>
                  <td><span style="margin-right:6px">${r.emoji}</span>${r.name.en}</td>
                  <td class="mono">${r.ageGroups.join(", ")}</td>
                  <td class="mono">${r.cookingTimeMin} min</td>
                  <td>${r.nutritionTags.map((n) => `<span class="tag nutri">${n}</span>`).join(" ")}</td>
                  <td>${r.allergens.length ? r.allergens.map((a) => `<span class="tag allergen">${a}</span>`).join(" ") : "—"}</td>
                  <td class="row-actions">
                    <button data-edit="${r.id}" title="Edit">✏️</button>
                    <button data-delete="${r.id}" title="Delete">🗑️</button>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </section>
      </main>
      ${editingId !== undefined ? "" : ""}
    `;
  }

  function computeStats() {
    const total = recipes.length;
    const avgTime = total ? Math.round(recipes.reduce((s, r) => s + r.cookingTimeMin, 0) / total) : 0;
    const withAllergens = recipes.filter((r) => r.allergens.length > 0).length;
    const byAge = {};
    AGE_GROUPS.forEach((a) => { byAge[a] = recipes.filter((r) => r.ageGroups.includes(a)).length; });
    return { total, avgTime, withAllergens, byAge };
  }

  /* ---------------- recipe form (add / edit) ---------------- */
  function emptyRecipe() {
    return {
      id: "", emoji: "🍽️",
      name: { en: "", hi: "" }, desc: { en: "", hi: "" },
      ageGroups: [], mealType: [], cookingTimeMin: 15, difficulty: "Easy",
      nutritionTags: [], allergens: [],
      ingredients: [""], instructions: [""],
      nutrition: { calories: 0, protein_g: 0, iron_mg: 0, calcium_mg: 0 },
      packingTip: { en: "", hi: "" }, kidTip: { en: "", hi: "" }
    };
  }

  function openForm(recipe) {
    const isNew = !recipe;
    const r = recipe ? JSON.parse(JSON.stringify(recipe)) : emptyRecipe();
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.id = "form-modal";
    backdrop.innerHTML = `
      <div class="modal" style="max-width:640px">
        <button class="modal-close" id="form-close">✕</button>
        <h2>${isNew ? "Add recipe" : "Edit recipe"}</h2>
        <form id="recipe-form" class="admin-form">
          <div class="form-row">
            <label>Emoji<input type="text" name="emoji" value="${r.emoji}" maxlength="4"></label>
            <label>Recipe ID (unique, no spaces)<input type="text" name="id" value="${r.id}" ${isNew ? "" : "readonly"} required></label>
          </div>
          <div class="form-row">
            <label>Name (English)<input type="text" name="name_en" value="${escAttr(r.name.en)}" required></label>
            <label>Name (Hindi)<input type="text" name="name_hi" value="${escAttr(r.name.hi || "")}"></label>
          </div>
          <div class="form-row">
            <label>Description (English)<input type="text" name="desc_en" value="${escAttr(r.desc.en)}"></label>
            <label>Description (Hindi)<input type="text" name="desc_hi" value="${escAttr(r.desc.hi || "")}"></label>
          </div>
          <div class="form-row">
            <label>Cooking time (minutes)<input type="number" name="cookingTimeMin" value="${r.cookingTimeMin}" min="1" required></label>
            <label>Difficulty
              <select name="difficulty">
                ${["Easy", "Medium", "Hard"].map((d) => `<option value="${d}" ${r.difficulty === d ? "selected" : ""}>${d}</option>`).join("")}
              </select>
            </label>
          </div>
          <div class="form-group">
            <label>Age groups</label>
            <div class="chip-row">${AGE_GROUPS.map((a) => `<label class="check-chip"><input type="checkbox" name="ageGroups" value="${a}" ${r.ageGroups.includes(a) ? "checked" : ""}> ${a}</label>`).join("")}</div>
          </div>
          <div class="form-group">
            <label>Meal type</label>
            <div class="chip-row">${MEAL_SLOTS.map((m) => `<label class="check-chip"><input type="checkbox" name="mealType" value="${m}" ${r.mealType.includes(m) ? "checked" : ""}> ${m}</label>`).join("")}</div>
          </div>
          <div class="form-group">
            <label>Nutrition tags</label>
            <div class="chip-row">${NUTRITION_ORDER.map((n) => `<label class="check-chip"><input type="checkbox" name="nutritionTags" value="${n}" ${r.nutritionTags.includes(n) ? "checked" : ""}> ${n}</label>`).join("")}</div>
          </div>
          <div class="form-group">
            <label>Allergens</label>
            <div class="chip-row">${ALLERGENS.map((a) => `<label class="check-chip"><input type="checkbox" name="allergens" value="${a}" ${r.allergens.includes(a) ? "checked" : ""}> ${a}</label>`).join("")}</div>
          </div>
          <div class="form-group">
            <label>Ingredients (one per line)</label>
            <textarea name="ingredients" rows="4">${r.ingredients.join("\n")}</textarea>
          </div>
          <div class="form-group">
            <label>Steps (one per line)</label>
            <textarea name="instructions" rows="4">${r.instructions.join("\n")}</textarea>
          </div>
          <div class="form-row">
            <label>Calories<input type="number" name="calories" value="${r.nutrition.calories}"></label>
            <label>Protein (g)<input type="number" name="protein_g" value="${r.nutrition.protein_g}"></label>
            <label>Iron (mg)<input type="number" step="0.1" name="iron_mg" value="${r.nutrition.iron_mg}"></label>
            <label>Calcium (mg)<input type="number" name="calcium_mg" value="${r.nutrition.calcium_mg}"></label>
          </div>
          <div class="form-row">
            <label>Packing tip (English)<input type="text" name="packingTip_en" value="${escAttr(r.packingTip.en)}"></label>
            <label>Parent tip (English)<input type="text" name="kidTip_en" value="${escAttr(r.kidTip.en)}"></label>
          </div>
          <div class="card-actions">
            <button type="submit" class="btn btn-primary">Save recipe</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(backdrop);
    backdrop.addEventListener("click", (e) => { if (e.target === backdrop) backdrop.remove(); });
    document.getElementById("form-close").addEventListener("click", () => backdrop.remove());
    document.getElementById("recipe-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const id = (fd.get("id") || "").toString().trim().toLowerCase().replace(/\s+/g, "-");
      if (!id) { alert("Please give the recipe a unique ID."); return; }
      if (isNew && recipes.some((x) => x.id === id)) { alert("That ID is already used by another recipe."); return; }
      const updated = {
        id,
        emoji: fd.get("emoji") || "🍽️",
        name: { en: fd.get("name_en"), hi: fd.get("name_hi") || fd.get("name_en") },
        desc: { en: fd.get("desc_en"), hi: fd.get("desc_hi") || fd.get("desc_en") },
        ageGroups: fd.getAll("ageGroups"),
        mealType: fd.getAll("mealType"),
        cookingTimeMin: Number(fd.get("cookingTimeMin")) || 15,
        difficulty: fd.get("difficulty"),
        nutritionTags: fd.getAll("nutritionTags"),
        allergens: fd.getAll("allergens"),
        ingredients: fd.get("ingredients").split("\n").map((s) => s.trim()).filter(Boolean),
        instructions: fd.get("instructions").split("\n").map((s) => s.trim()).filter(Boolean),
        nutrition: {
          calories: Number(fd.get("calories")) || 0,
          protein_g: Number(fd.get("protein_g")) || 0,
          iron_mg: Number(fd.get("iron_mg")) || 0,
          calcium_mg: Number(fd.get("calcium_mg")) || 0
        },
        packingTip: { en: fd.get("packingTip_en"), hi: r.packingTip.hi || "" },
        kidTip: { en: fd.get("kidTip_en"), hi: r.kidTip.hi || "" }
      };
      if (isNew) {
        recipes.push(updated);
      } else {
        recipes = recipes.map((x) => (x.id === id ? updated : x));
      }
      window.TinyTiffinStore.saveRecipes(recipes);
      backdrop.remove();
      render();
    });
  }

  function escAttr(s) { return String(s || "").replace(/"/g, "&quot;"); }

  /* ---------------- export / import ---------------- */
  function downloadFile(filename, content, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  }

  function exportRecipesJs() {
    const header = `/* Tiny Tiffin — Recipe Database (exported from Admin Panel) */\nwindow.TINY_TIFFIN_RECIPES = `;
    const content = header + JSON.stringify(recipes, null, 2) + ";\n";
    downloadFile("recipes.js", content, "text/javascript");
  }

  function exportJson() {
    downloadFile("tiny-tiffin-recipes-backup.json", JSON.stringify(recipes, null, 2), "application/json");
  }

  function importJson(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        if (!Array.isArray(parsed)) throw new Error("not an array");
        recipes = parsed;
        window.TinyTiffinStore.saveRecipes(recipes);
        render();
      } catch (e) {
        alert("That file doesn't look like a valid Tiny Tiffin recipe export.");
      }
    };
    reader.readAsText(file);
  }

  /* ---------------- events ---------------- */
  function attachEvents() {
    if (!authed) {
      const submit = document.getElementById("pw-submit");
      const input = document.getElementById("pw-input");
      const tryLogin = () => {
        if (input.value === ADMIN_PASSWORD) {
          authed = true; sessionStorage_set("tt_admin_authed", true); render();
        } else {
          input.value = ""; input.placeholder = "Incorrect password — try again"; input.focus();
        }
      };
      if (submit) submit.addEventListener("click", tryLogin);
      if (input) input.addEventListener("keydown", (e) => { if (e.key === "Enter") tryLogin(); });
      return;
    }
    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) logoutBtn.addEventListener("click", () => { authed = false; sessionStorage_set("tt_admin_authed", false); render(); });

    const addBtn = document.getElementById("add-recipe-btn");
    if (addBtn) addBtn.addEventListener("click", () => openForm(null));

    root.querySelectorAll("[data-edit]").forEach((btn) => {
      btn.addEventListener("click", () => openForm(recipes.find((r) => r.id === btn.dataset.edit)));
    });
    root.querySelectorAll("[data-delete]").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (confirm("Delete this recipe? This can't be undone.")) {
          recipes = recipes.filter((r) => r.id !== btn.dataset.delete);
          window.TinyTiffinStore.saveRecipes(recipes);
          render();
        }
      });
    });

    const exportBtn = document.getElementById("export-btn");
    if (exportBtn) exportBtn.addEventListener("click", exportRecipesJs);
    const exportJsonBtn = document.getElementById("export-json-btn");
    if (exportJsonBtn) exportJsonBtn.addEventListener("click", exportJson);
    const importInput = document.getElementById("import-input");
    if (importInput) importInput.addEventListener("change", (e) => { if (e.target.files[0]) importJson(e.target.files[0]); });
    const discardBtn = document.getElementById("discard-draft-btn");
    if (discardBtn) discardBtn.addEventListener("click", () => {
      if (confirm("Discard all unsaved draft changes and go back to the published recipes?")) {
        window.TinyTiffinStore.clearDraft();
        recipes = window.TinyTiffinStore.getRecipes().map((r) => JSON.parse(JSON.stringify(r)));
        render();
      }
    });
  }

  render();
})();
